wrt1.5.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 6 payloads.
Update of wrt.exe:
Changed some GDI effects, the MBR and it will open more programs.