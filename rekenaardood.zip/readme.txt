rekenaardood.exe
This malware is simply dangerous!
It was made ONLY for educational and entertainment purposes.
Works on Windows XP-11.
Note: this malware is an AI slop
Credits to pankoza for opener, message box from DETTAMROFNIW and textz from Getaparane
My new HSL and RGBQUAD malware for this time I've ever made.
Do NOT run this malware on real devices/hardwares, otherwise the MBR will overwrite it.
Run it ONLY on a VM instead!
For skidders:
I know if these skidders are copying to these malware.
If you don't steal these effects, credits to me.
Thank you.