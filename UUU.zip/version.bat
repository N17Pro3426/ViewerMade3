@echo off
title UUU.exe
echo Note: this is my new malware at this time.
echo You got opened winver.exe.
echo By the way, it's a secret.
start winver.exe
pause
exit