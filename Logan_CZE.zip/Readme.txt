Logan_CZE.exe by VietNamLover.
Credits to Logan_CZE for the name.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 15 payloads.
Differences compared to getoutofmyhead.exe by Hexademical:
Changed all bytebeats and the MBR.
Hexademical gave me permission to remake his malware.