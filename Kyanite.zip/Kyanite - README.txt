It's about time I'm finally making a README on a malware after months of not making one.
So today, I'm presenting:
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
 ___  ____                             _   _                                     ||
|_  ||_  _|                           (_) / |_                                   ||
  | |_/ /     _   __  ,--.   _ .--.   __ `| |-'.---.    .---.  _   __  .---.     ||
  |  __'.    [ \ [  ]`'_\ : [ `.-. | [  | | | / /__\\  / /__\\[ \ [  ]/ /__\\    ||
 _| |  \ \_   \ '/ / // | |, | | | |  | | | |,| \__., _| \__., > '  < | \__.,    ||
|____||____|[\_:  /  \'-;__/[___||__][___]\__/ '.__.'(_)'.__.'[__]`\_] '.__.'    ||
             \__.'                                                               ||
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
A malware created by myself (UltraDasher965).
This is a program that I've been creating for Hexademical's malware contest for a week now and I think this is the best malware I have ever made since then.
To answer a few questions:

Q1. What is Kyanite.exe and what is it designed to do?
R1. Kyanite is a GDI trojan that is designed to add lots of flashing lights onto your computer and play loud sounds and I promise you it's not for the
    weak people. Also running the version without the "-safety" label on your main PC may result in permanent data loss and you then have to either reinstall
    Windows or switch drives.

Q2. What is GDI?
R2. GDI, also known as "Graphics Design Interface", is a Microsoft Windows API used for representing graphical objects and transmitting them to output
    devices such as monitors and printers, enabling applications to render text and graphics efficiently. (I took it from the internet lmao I'm so tired rn)

Q3. What are the systems to play sounds coming from Kyanite?
R3. They can be generated using bytebeat and there are 2 systems for that:
1. The most common one being pankoza's sound system. It only plays sounds that don't exceed 32KHz and memleaks when this limit is exceeded. You can find it
   in most his malwares in exception of our collab malware called pentacyanocyclopentadiene.exe.
2. My own sound system, which can play 32KHz+ sounds without memleaking. This malware was first used in Camelopardalis.exe by me & my brother syexunii (it
   got tested by Crypto NWO on his 13th episode lmao) and was then used by pankoza for our collab malware.

Q4. Hi Crypto NWO, if you're testing this malware, just know that this readme took me 25 fucking minutes to make.
R4. voop

Hello Hexademical, N17Pro3426, syexunii & more!























































If you have scrolled down, enjoy the wrath of the

          _____          
         /\    \         
        /::\    \        
       /::::\    \       
      /::::::\    \      
     /:::/\:::\    \     
    /:::/__\:::\    \    
   /::::\   \:::\    \   
  /::::::\   \:::\    \  
 /:::/\:::\   \:::\    \ 
/:::/__\:::\   \:::\____\
\:::\   \:::\   \::/    /
 \:::\   \:::\   \/____/ 
  \:::\   \:::\    \     
   \:::\   \:::\____\    
    \:::\   \::/    /    
     \:::\   \/____/     
      \:::\    \         
       \:::\____\        
        \::/    /        
         \/____/         
                         .