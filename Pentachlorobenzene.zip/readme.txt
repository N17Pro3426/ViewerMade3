 ____            _             _     _                 _                                                  
|  _ \ ___ _ __ | |_ __ _  ___| |__ | | ___  _ __ ___ | |__   ___ _ __  _______ _ __   ___   _____  _____ 
| |_) / _ \ '_ \| __/ _` |/ __| '_ \| |/ _ \| '__/ _ \| '_ \ / _ \ '_ \|_  / _ \ '_ \ / _ \ / _ \ \/ / _ \
|  __/  __/ | | | || (_| | (__| | | | | (_) | | | (_) | |_) |  __/ | | |/ /  __/ | | |  __/|  __/>  <  __/
|_|   \___|_| |_|\__\__,_|\___|_| |_|_|\___/|_|  \___/|_.__/ \___|_| |_/___\___|_| |_|\___(_)___/_/\_\___|
(A remake of APM 08279+5255.exe)

Probably one of my best remakes so far...
This malware is 10-12 minutes long, because 25 payloads ofc and one payload is 60 seconds.
This malware is dangerous, so don't run it on your main PC, unless it's a spare device.
Created by Nyexev
Finished creation date: November 23, 2026.
Good luck.