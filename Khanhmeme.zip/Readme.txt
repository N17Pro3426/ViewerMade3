Khanhmeme.exe by VieNamLover.
Credits to Im_khanh for the name.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 25 payloads.
Huge thanks to N17Pro3426 for told me how to fix this malware!
Differences compared to hexafluoride.exe by N17Pro3426:
Changed all bytebeats, texts and the MBR.
N17Pro3426 gave me permission to remake his malware.