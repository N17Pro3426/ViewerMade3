This is dwnn.exe, but I fixed the MBR.
Don't run this malware on your real PC!
Thanks to N17Pro3426 for told me how to fix the MBR!
Made by VietNamLover.































If N17Pro3426 is reading this, hi!