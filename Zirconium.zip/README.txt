Zirconium.exe
An randomized GDI malware
The payloads and sounds are random.
The creator is NOT responsible for ANY damages.