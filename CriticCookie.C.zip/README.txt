CriticCookie.C.exe GDI malware
Took me 1-2 days to make
This malware is NOT skidded
I'm NOT responsible for ANY damages caused by running this malware.
This shall NOT be used in any illegal activity.
Run this at your own risk.
The destructive version will wipe the MBR, disable all system utilities like Command Prompt, Task Manager and more.
Run it ONLY in a VM you're ok with losing!
The safety version is safe and can be run on a real PC, but it still contains epilepsy and restart is recommended.
Happy Halloween btw!
Made by CriticCookie
Creation date: October 31, 2026
:D