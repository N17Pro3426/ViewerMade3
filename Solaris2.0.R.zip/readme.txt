+---------------------+
Solaris2.0.R.exe
+---------------------+
Don't delete sounds.wav
This malware is not destructive...
Creation date: November 8, 2026
Works in Windows XP-11
Credits to Clxcq for the original SKIDDED malware
Credits to pankoza for the payload from svg
Credits to N17Pro3426 for the wave, wef and invert