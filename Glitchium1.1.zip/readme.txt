A new version of Glitchium.exe
Credits to pankoza for the program opener (System32), MBR wiper and textz I think
Works in Windows XP-11
If you run destructive version as admin, the MBR will instantly overwrite your PC.
Do NOT run this malware on your main PC!
Use ONLY a VM instead.
By the way, this malware is a slop, because AI.