Malware name: 0xdeadbeef.exe
Does it have a safe version?: Yes
Creator: Hexademical (Facing Demons)
---Informational text---
It can overwrite your bootsector with BCD, so your system can't boot again.
But, you can test the safe version, so that your system doesn't die. :P