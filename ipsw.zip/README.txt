ipsw.exe GDI trojan
This causes a lot of damage to any computer its ran on.
I'm NOT responsible for ANY damages caused by running this malware!
Run at your own risk, this is ONLY for educational purposes.
Made by CriticCookie