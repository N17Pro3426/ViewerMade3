mdm.exe GDI malware
It took me a few days to make
Created by CriticCookie
This malware is NOT to be used in ANY illegal activity including harming others or running this on protected systems.
I'm NOT responsible for ANY damages caused by running this malware.
Run this at your own risk.
The safety version doesn't destroy your PC.