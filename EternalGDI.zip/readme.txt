EternalGDI.exe
-----------------------
Written in: Dev-C++ 5.11
Works in Windows XP-11
My new GDI malware.
Note: totally AI slop