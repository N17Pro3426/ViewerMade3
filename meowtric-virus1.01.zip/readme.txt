meowtric-virus.exe
Created by yTeraBonus & N17Pro3426
Works on Windows Vista-11

This is a GDI malware.
The creators are NOT responsible for ANY damages.

Creators GitHub pages:
https://github.com/yTeraBonus
https://github.com/N17Pro3426

Bugfix:
Added ExitProcess and now it's 1.5 minutes long.