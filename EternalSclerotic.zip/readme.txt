EternalSclerotic.exe
+----------------------------+
My remake of Sclerosis by hessfire.
Credits to hessfire for this sound file.
Works in Windows XP-11
Warning! Loud noises and flashing lights ahead!
By running it on a main PC can cause any trouble or damages!