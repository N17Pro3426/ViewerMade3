nitroline.exe
------------------
My first GDI+ trojan, just like C#.
Written in: Dev-C++ 5.11
Programming language: C++
Destructive rate: Ultimate
Author: transdows (also known as NULLWARE)
Creation date: November 22, 2026
Compatibility: Windows XP-11
By running this on a main PC will cause any damages!
Epilepsy warning and loud noises ahead!
It's NOT for criminal purposes!
Anyone who can test my first GDI+ trojan.