disk1.1.1.exe
------------------+
Totally a new destructive trojan I made :D
Written in: Dev-C++ 5.11
Works on Windows XP-11
This malware contains flashing lights, NOT for people with epilepsy.
Credits to Dominik111 for the payload from Holzer?
Credits to pankoza for the message box (thank you)
The MBR is from Aylum (skidded malware by Tromiute)