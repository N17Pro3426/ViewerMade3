quarantine3.1.exe
+-------------------------+
My new GDI malware.
Inspired by Tera Bonus, neptunium, Hyptonium and Monoxide
Written in: Dev-C++ 5.11
Created by transdows666
Credits to pankoza for some payloads
Note: this malware is AI slop, thanks