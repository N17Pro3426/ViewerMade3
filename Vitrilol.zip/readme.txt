Vitrilol.exe
Original by Xip333
Works in Windows XP-11
Creation date: November 25, 2026 (not last creation on July 2026)
Anyone who can test my malware