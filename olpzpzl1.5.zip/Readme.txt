olpzpzl1.5.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 14 payloads.
Update of olpzpzl.exe:
Changed some bytebeats and the MBR.