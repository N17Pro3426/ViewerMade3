MonoxideOldR.exe
+--------------------------+
My remake of Monoxide.
Works on Windows XP-11
Written in: Dev-C++ 5.11
Credits to Xip333 for the original malware-remake