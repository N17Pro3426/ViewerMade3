Beziriti1.5.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
If you want to run it properly, change the display resolution to 1024×768.
This GDI malware has 20 payloads.
Update of Beziriti.exe:
Changed some bytebeats.