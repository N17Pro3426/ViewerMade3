bzvftigvf.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 16 payloads.
Differences compared to btfoiuthns.exe by pankoza:
Changed all bytebeats, text and the MBR.