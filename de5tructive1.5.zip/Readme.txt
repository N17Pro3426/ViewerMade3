de5tructive1.5.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 7 payloads.
Thanks to N17Pro3426 for the 1st bytebeat, but i modified it.
Update of de5tructive.exe:
Changed all bytebeats.