lassium.exe by VietNamLover
This malware runs ONLY on 64-bit operating systems.
You need to install Visual C++ 2017 or 2015-2019 before running this malware.
This is a 20 payload malware.
Created on: August 19, 2026
This malware has a lot of destructive potential, so run it ONLY in a VM.
It contains flashing lights and loud sounds, so it's NOT for people with epilepsy or other similar medical conditions.