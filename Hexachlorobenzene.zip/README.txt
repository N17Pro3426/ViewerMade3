Hexachlorobenzene.exe GDI malware
Idk why this took me 2 weeks I think to make, because of power outages.
I'm NOT responsible for ANY damages caused by running this malware.
This shall NOT be used in any illegal activity.
Run this at your own risk.
The destructive version will wipe the MBR, disable all system utilities like Command Prompt, Task Manager and more.
Data loss will occur.
Run it ONLY in a VM you're ok with losing!
The safety version is safe and can be run on real PC, but it still contains epilepsy.
Made by CriticCookie
:D