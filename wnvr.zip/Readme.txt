wnvr.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM!
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 11 payloads.
Differences compared to Holmium.exe by pankoza:
Changed all bytebeats, texts and the MBR.