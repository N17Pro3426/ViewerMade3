vine.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
Credits to nguyentuananh for the name.
Credits to N17Pro3426 for the 14th bytebeat.
Enjoy this 20 payload malware!