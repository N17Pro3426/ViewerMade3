 __    __                                         
|  \  |  \                                        
| $$  | $$  ______   _______    ______   _______  
 \$$\/  $$ /      \ |       \  /      \ |       \ 
  >$$  $$ |  $$$$$$\| $$$$$$$\|  $$$$$$\| $$$$$$$\
 /  $$$$\ | $$    $$| $$  | $$| $$  | $$| $$  | $$
|  $$ \$$\| $$$$$$$$| $$  | $$| $$__/ $$| $$  | $$
| $$  | $$ \$$     \| $$  | $$ \$$    $$| $$  | $$
 \$$   \$$  \$$$$$$$ \$$   \$$  \$$$$$$  \$$   \$$
                
This program is not dangerous, it's just a GDI effects project.
Works better on Windows XP and 7.
This is my 2nd GDI project!
Xenon is a Win32 GDI/GDI+ visual and audio effects project featuring 26 sequential stages with custom math-generated sound synthesis.
This project contains fast flashing lights, screen distortion and high-frequency audio.
Wroten on the C++ language and in Visual Studio Code.