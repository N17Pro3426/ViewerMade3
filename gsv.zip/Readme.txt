gsv.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 8 payloads.
Differences compared to svg.exe by pankoza:
Changed all bytebeats, texts and the MBR.