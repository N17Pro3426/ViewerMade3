    __  __                     __                           _     
   / / / /__  ____ ___  ____ _/ /____  ____ ___  ___  _____(_)____
  / /_/ / _ \/ __ `__ \/ __ `/ __/ _ \/ __ `__ \/ _ \/ ___/ / ___/
 / __  /  __/ / / / / / /_/ / /_/  __/ / / / / /  __(__  ) (__  ) 
/_/ /_/\___/_/ /_/ /_/\__,_/\__/\___/_/ /_/ /_/\___/____/_/____/  

Hematemesis.exe (vomiting of blood)
A GDI collab malware made between Hexademical (@hexademical-o9z) and N17Pro3426 (@nazar7346)
Special shoutout for Ashlyn for giving me the message box with white noise.
This malware is 23 payloads long.
Do NOT run this on a main physical device.
This malware will damage the boot record and delete BCD (Boot Configuration Data)
If you want to run this on a real computer, run the safety version.
But if you have a Virtual Machine or a spare physical device, run the destructive version.
Hello UltraDasher965, Venra, Sapphire, N17Pro3426 and anyone else testing this! :3