Dysprosium.exe
A new malware from September.
Did I have a damage rate? No, it can taskkill services.exe and dwm.exe.
So, you need to run it as administrator.
Don't run the destructive version on real hardware (use a VM instead), but I advise you to try it!
Do I have a safety program? Yes, it's named "Dysprosium-safety.exe".
Anyways, I'm NOT responsible for ANY damages. 
For skidders: MazeIcon, do NOT skid this, cuz I don't have source code.
Go fuck yourself, MazeIcon.
Credits to kapi2.0peys for this warning.
Hi N17Pro3426, VietNamLover, Windows PC and more!