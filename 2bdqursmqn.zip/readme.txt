2bdqursmqn.exe
My new GDI malware
Creation date: November 6, 2026
Written in: C++
Do NOT run this malware on your main PC!
Credits to the author for the bouncing rectangle
Credits to pankoza for the MBR
Credits to GetMbr and Malsteve for the HSL function
Spoiler: "GetMbr HSL function in the big 26" and "AI ass trojan"