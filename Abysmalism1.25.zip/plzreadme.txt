     ___      .______   ____    ____  _______..___  ___.      ___       __       __       _______..___  ___.     __________   ___  _______ 
    /   \     |   _  \  \   \  /   / /       ||   \/   |     /   \     |  |     |  |     /       ||   \/   |    |   ____\  \ /  / |   ____|
   /  ^  \    |  |_)  |  \   \/   / |   (----`|  \  /  |    /  ^  \    |  |     |  |    |   (----`|  \  /  |    |  |__   \  V  /  |  |__   
  /  /_\  \   |   _  <    \_    _/   \   \    |  |\/|  |   /  /_\  \   |  |     |  |     \   \    |  |\/|  |    |   __|   >   <   |   __|  
 /  _____  \  |  |_)  |     |  | .----)   |   |  |  |  |  /  _____  \  |  `----.|  | .----)   |   |  |  |  |  __|  |____ /  .  \  |  |____ 
/__/     \__\ |______/      |__| |_______/    |__|  |__| /__/     \__\ |_______||__| |_______/    |__|  |__| (__)_______/__/ \__\ |_______|
(1.25 version)
--------------------------------------------------------------------------------------------------------------------------------------------
A 10 minute long malware I made for AntennaeTech's canceled competition! :D
I hope you enjoy this randomized malware that I made...
It's recommended to turn on BIOS mode, so you can see the MBR
(Actually, it's a remake of my old unreleased malware Insanity.exe, that is actually ass, but ts is way better!)
Hello AntennaeTech, N17Pro3426, UltraDasher965, Venrastuff, crzxyminty and anyone who is testing it!
Updates that have been made: There are over 20+ GDI effects, 19 audio sequences... and changed some things!
I won't publish the source code, so don't even think about it.