dcfvgrf.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 21 payloads.
Credits to N17Pro3426 for the MBR.
Differences compared to Alkyl octanitrogen.exe by LambdaTech:
Changed all texts, some GDI effects and bytebeats.
Messages to LambdaTech:
1. I know you're a anti-skid guy, but I'm a noob malware creator, so I always skid (sorry for that).
2. I got the source code on: https://github.com/N17Pro3426/Source-Codes