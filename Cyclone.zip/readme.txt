Cyclone.exe
+--------------------+
This bouncing window was inspired by Deadline
My new GDI malware
Works in Windows XP-11
Note: it's AI slop