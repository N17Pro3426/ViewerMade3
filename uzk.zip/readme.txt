uzk.exe by VietNamLover
Credits to Clutter xmodz for the name.
This malware runs ONLY on 64-bit operating systems.
You need to install Visual C++ 2017 or 2015-2019 before running this malware.
This is a 7 payload malware.
Created on: August 24, 2026
This malware has a lot of destructive potential, so run it ONLY in a VM.
It contains flashing lights and loud sounds, so it's NOT for people with epilepsy or other similar medical conditions.
Differences compared to barrelene.exe by N17Pro3426 (he let me to remake his malware):
Added 1 more payload, changed all bytebeats, texts and MBR.