ColorCs2.0.exe
A remake of ColorCs
Works in Windows XP-11
This malware is probably slop.
Credits to kapi2.0peys for the original malware, warnings and bytebeats
Credits to ArTicZera for the blur effect
Credits to N17Pro3426 for the textz payload
Credits to pankoza for the program opener