Verity.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
Credits to NimBoot for the MBR.
Enjoy this 15 payload malware!