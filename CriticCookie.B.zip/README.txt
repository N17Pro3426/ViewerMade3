CriticCookie.B.exe GDI malware
It took days to make I think a week
I'm NOT responsible for ANY damages caused by running this malware.
This shall NOT be used in any illegal activity.
Run this at your own risk.
The destructive version will wipe the MBR, disable all system utilities like Command Prompt, Task Manager and more and delete all volume partition from A-Z.
Data loss will occur.
Run it ONLY in a VM, you're ok with losing!
The safe version is safe and can be run on real PC, but it still contains epilepsy.
:D