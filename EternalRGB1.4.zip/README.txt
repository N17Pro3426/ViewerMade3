 _______  _________  _______   ________  ________   ________  ___       ________  ________  ________     
|\  ___ \|\___   ___\\  ___ \ |\   __  \|\   ___  \|\   __  \|\  \     |\   __  \|\   ____\|\   __  \    
\ \   __/\|___ \  \_\ \   __/|\ \  \|\  \ \  \\ \  \ \  \|\  \ \  \    \ \  \|\  \ \  \___|\ \  \|\ /_   
 \ \  \_|/__  \ \  \ \ \  \_|/_\ \   _  _\ \  \\ \  \ \   __  \ \  \    \ \   _  _\ \  \  __\ \   __  \  
  \ \  \_|\ \  \ \  \ \ \  \_|\ \ \  \\  \\ \  \\ \  \ \  \ \  \ \  \____\ \  \\  \\ \  \|\  \ \  \|\  \ 
   \ \_______\  \ \__\ \ \_______\ \__\\ _\\ \__\\ \__\ \__\ \__\ \_______\ \__\\ _\\ \_______\ \_______\
    \|_______|   \|__|  \|_______|\|__|\|__|\|__| \|__|\|__|\|__|\|_______|\|__|\|__|\|_______|\|_______| version　1.4
|===----------------------------------------------------------------------------------------------------------------------------------------------===|
my final contribution to this god forsaken community damn it もう無理やこのコミュニティがーー                                                                                   
##     ##    ###    ########  ########   ########  ##    ##   ######## ########  ##     ## ##        #######  ##    ## ######## ##  ##      ## 
###   ###   ## ##   ##     ## ##         ##     ##  ##  ##       ##    ##     ## ##     ## ##       ##     ## ###   ## ##       ##  ##      ##
#### ####  ##   ##  ##     ## ##         ##     ##   ####        ##    ##     ## ##     ## ##       ##     ## ####  ## ##        ##  ##     ##
## ### ## ##     ## ##     ## ######     ########     ##         ##    ########  ##     ## ##       ##     ## ## ## ## ######    ##  ##   ##
##     ## ######### ##     ## ##         ##     ##    ##         ##    ##   ##   ##     ## ##       ##     ## ##  #### ##                ##
##     ## ##     ## ##     ## ##         ##     ##    ##         ##    ##    ##  ##     ## ##       ##     ## ##   ### ##            ####
##     ## ##     ## ########  ########   ########     ##         ##    ##     ##  #######  ########  #######  ##    ## ########  ####
|===----------------------------------------------------------------------------------------------------------------------------------------------===|
Ever wondered what EternalRed + EternalGreen + EternalBlue would result in? Here's your answer! With 28 layered shaders, 19 GDI payloads, 29 audio
sequences, a fake BSOD sequence and a custom warning box, EternalRGB is an extremely destructive malware written in C created for entertainment,
educational and analytical purposes that draws inspiration from Sulfoxide, quantizer, Monoxide, solaris and more. (Gotta credit wipet for the fact
that this is inspired by so much of his stuff, he's the GOAT at this)

It possesses the ability to render your OS completely unrecoverable, trashing potentially your entire registry (including HKEY_LOCAL_MACHINE), 
corrupting every single file on every device connected to the machine and replacing the boot sector. It also completely screws over your control of
the PC, spamming random mouse and keyboard inputs, as well as forcing messages and enumeration on every window open.

As such, you should NEVER EVER run this malware on a real PC, especially since this isn't supposed to be used for malicious purposes, so I'm NOT
responsible for ANY damages done to any PCs by this malware.

Recommended to run this on the following OSes for best performance: Windows XP, Windows Vista (turn off Aero) and Windows 7 (turn off Aero). Also,
run this as administrator and/or UAC turned off, the destruction will not work properly otherwise! Higher resolutions are also not recommended, as
it means the shaders have to render more pixels, thus making them laggier. Lower to something like 1080p or 720p. This malware can get insanely laggy
due to all of the WinAPI spamming and drive querying. If HKEY_LOCAL_MACHINE gets corrupted, the screen WILL be black, in that case tough luck, you're
gonna have to run the malware again.

Special thanks and greetings to Xidroria (provided several assets), TijnAG07, VortexGTX (zzenuws) and Isolynx (GetMbr)