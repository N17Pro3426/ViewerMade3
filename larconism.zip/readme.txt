larconism.exe
+-------------------+
My new malware + comeback
Works in Windows XP-11
Made with AI? Yes...
The safety version won't destroy your PC.
By running destructive one on your PC will destroy your local disks.