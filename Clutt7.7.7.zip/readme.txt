Clutt7.7.7.exe
Skidded malware by NullOS404
Works in Windows XP-11
Creation date: November 5, 2026
A remake of Clutt6.6.6
Credits to ClutterTech for the sounds from Clutt6.6.6