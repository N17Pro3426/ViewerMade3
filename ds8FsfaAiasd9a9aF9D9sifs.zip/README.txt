ds8FsfaAiasd9a9aF9D9sifs.exe
This GDI malware will corrupt the device and make it unusable.
Creator: yTeraBonus
Made at midnight.
Made from Russia.