yuki aim.exe by VietNamLover.
Credits to Clutter xmodz for the name.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 7 payloads.
Differences compared to flv.exe by pankoza:
Changed some payloads, bytebeats, all texts and the MBR.