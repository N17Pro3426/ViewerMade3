PLG.exe
A GDI trojan by Comium92
Type: Trojan.KillMBR
Made in: Dev-C++
Damage rate: Destructive
Works best in: Windows 2000 or earlier
Credits to Mattia for the MBR
Credits to nikitpad for the RGBQUAD