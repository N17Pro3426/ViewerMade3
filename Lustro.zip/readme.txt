﻿Malware name: Lustro
Malware type: Trojan
Damage rate: Destructive
Works best in: Windows 2000 or newer
Created in: Dev-C++
Malware author: Comium92
Do NOT test it on a real PC, I'm (Comium92) NOT responsible for ANY damages!