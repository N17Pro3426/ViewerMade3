Phenyrane1.5.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 10 payloads.
Update of Phenyrane.exe:
Changed some bytebeats and texts.