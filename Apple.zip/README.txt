Hey, ItzCrazySonicFan here.
Just so you'd know, this is NOT a malware.
It's a safe joke program that turns your desktop to Bad Apple and it can be terminatable through Task Manager or taskkill.exe.
Though only suspicious thing it can do is refuse to open any program like just minimize it in loop, but overall, it's safe.
If you want to know what Bad Apple is, watch it at https://www.youtube.com/watch?v=FtutLA63Cp8