-------------------------
|Another collab malware!|
-------------------------
Wow! Hand-made text decoration. :P
---------------------------------------------------------------------------------------------------------------------------------------
|Exisonemehtotajiemoasly.exe by Luma <3/Ashlyn and Hexademical                                                                        |
|20 payload long GDI malware.                                                                                                         |
|Luma's contribution to this malware: First 10 GDI payloads and bytebeats + warnings                                                  |
|Hexademical's contribution to this malware: Second 10 GDI payloads and bytebeats, modified WinMain, modified warnings a bit, added a |
|spamming message box with random unicode strings in it, MBR, disabler things and BCD deletion.                                       |
|Both of us wish that you'll like this malware we made! :D                                                                            |
---------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------
|Hello UltraDasher965, N17Pro3426, Venra and more of you! :3|
-------------------------------------------------------------