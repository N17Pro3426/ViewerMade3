isopropylate.exe GDI malware
Created by CriticCookie
Credits to VietNamLover for some effects and bytebeats
The destructive version wipes the MBR and corrupts the OS BCD.
Made ONLY for educational purposes.
Do NOT use any for illegal activity or harming others.
The safe version can also lag your PC and it still shakes and moves the cursor and windows.
The info version just shows some additional short version of this (it's not destructive)
(Took me maybe a week or 2 to make idk)