Structium1.5.exe by VietNamLover.
Don't run this malware on your real PC!
This GDI malware has 20 payloads (21 if you count the outro).
Update of Structium.exe:
Changed some bytebeats and the MBR.