Credits to masteralbert100 for icon and name
Inspired by mawaru.exe (please wait window) and yeah maybe it's skidded or not?
Sorry for a small text, but don't worry.