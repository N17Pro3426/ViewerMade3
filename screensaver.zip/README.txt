  █████   ██████  ████████   ██████   ██████  ████████    █████   ██████   █████ █████  ██████  ████████ 
 ███░░   ███░░███░░███░░███ ███░░███ ███░░███░░███░░███  ███░░   ░░░░░███ ░░███ ░░███  ███░░███░░███░░███
░░█████ ░███ ░░░  ░███ ░░░ ░███████ ░███████  ░███ ░███ ░░█████   ███████  ░███  ░███ ░███████  ░███ ░░░ 
 ░░░░███░███  ███ ░███     ░███░░░  ░███░░░   ░███ ░███  ░░░░███ ███░░███  ░░███ ███  ░███░░░   ░███     
 ██████ ░░██████  █████    ░░██████ ░░██████  ████ █████ ██████ ░░████████  ░░█████   ░░██████  █████    
=============================================================================================
Hello there! This is my new GDI malware made in C (remake of quantizer by wipet) displaying GDI effects
on your screen using layered windows and even supporting stereo sound generation! This took about a month
and a half to make.

This malware uses layered windows mixed together with normal GDI to create interesting screen effects.
Another unique aspect of this malware is stereo bytebeat generation, which was surprisingly easy to implement.
And finally, instead of being an .exe file like basically any other GDI malware, this one uses the .scr file
extension, which works absolutely identical to a normal .exe file, but is identified by Windows as a "Screen
Saver", which fits well for the malware's name!

I also challenged myself to make my very own bootloader payload for this project, which I've never really
done before due to my lack of Assembly knowledge. With the help of my good friend, I learned some Assembly
and made my own bootloader payload displaying rainbow visuals made using math, with 9 different formulas
available to be randomly chosen on boot!
=============================================================================================
REGISTRY
There are a few registry values that can be used for screensaver:
1. Key: HKEY_CURRENT_USER\Software\screensaver
2. Block: A DWORD value of 1 will prevent screensaver from executing completely, it will refuse to run and
   display a message box informing the user that it's blocked.
3. SafeMode: A DWORD value of 1 will prevent screensaver from launching destructive payloads.
   (⚠ Important! If the message box does NOT say screensaver is running in safe mode, then it's NOT running
   in safe mode! Additionally, the malicious code is still in the binary, so executing screensaver on real
   hardware is NOT recommended! ⚠)
4. DisableLayeredWindows: A DWORD value of 1 will disable all layered window payloads in case your machine
   isn't compatible with them. It is important to note that on Windows 10+ this value would disable ALL GDI
   payloads.
5. Seed: Any non-zero DWORD value will set the randomizer's seed to that value, and therefore all runs with
   this seed will be the exact same.
=============================================================================================
COMPATIBILITY
1. Both x86 and x64 work!
2. Windows XP
3. Windows Vista and 7 (DWM will be disabled if not already using a Basic or Classic theme)
4. Windows 8-10 before version 2004 (no layered window support)
5. Windows 10 version 2004+ (has layered window support, but the GDI payloads are limited due to issues with
   the layered window compatibility method)
=============================================================================================
KNOWN BUGS
1. Lack of layered windows on Windows 8-10, as listed in Compatibility (but there isn't much that can be done
   about it)
2. Black screen on Windows Vista if running with Aero (enable a Basic theme manually before running)
3. Sound stopping on modern Windows (this is caused by registry corruption)
=============================================================================================
Credits to lostbytes for Modern Windows support using SetWindowDisplayAffinity
Credits to xdq_0 for the name suggestion back in September 2025
=============================================================================================
LICENSE
This project uses the GPL-3.0 license!
This basically means that if you use this project's code, you MUST credit me, open source your project and
also set the license to GPL-3.0!
=============================================================================================
Made by silverjetes <3
11/26