Credits to PB95Player2024 for texts, icon and name
Credits to pankoza and N17Pro3426 for some payloads
Credits to kapi2.0peys for 3 bytebeats
Btw, this is my first sloppy malware