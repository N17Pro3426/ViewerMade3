I'm NOT responsible for ANY damages caused by running this malware.
Run it ONLY on a VM!
Also, the BSOD version just removes the disablers, MBR wipe and your computer will crash at the end, but it still be bootable.
:D