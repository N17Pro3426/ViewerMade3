,--.   ,--.                      ,--.,--.,--.                        ,--.   ,--.                            
 \  `.'  /,---. ,--.  ,--.,--,--.|  ||  |`--',--.,--.,--,--,--.,-----.\  `.'  /      ,---. ,--.  ,--.,---.  
  \     /| .-. : \  `'  /' ,-.  ||  ||  |,--.|  ||  ||        |'-----' .'    \      | .-. : \  `'  /| .-. : 
   \   / \   --. /  /.  \\ '-'  ||  ||  ||  |'  ''  '|  |  |  |       /  .'.  \ .--.\   --. /  /.  \\   --. 
    `-'   `----''--'  '--'`--`--'`--'`--'`--' `----' `--`--`--'      '--'   '--''--' `----''--'  '--'`----' 

A 15 payload long malware made by me...
This malware is finally Windows XP compatible! So, that means you can run it on Windows XP-11!
Destructive?: Fuck yes.
Hello N17Pro3426, AntennaeTech, UltraDasher965, Marlon2210 and anyone else testing this!
:D