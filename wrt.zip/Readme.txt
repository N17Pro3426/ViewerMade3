wrt.exe by VietrNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 6 payloads.
Differences compared to Fluorocarbomorpholide.exe by fr4ctalz:
Changed some GDI effects.