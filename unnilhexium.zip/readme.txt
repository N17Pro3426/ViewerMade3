Credits to pankoza for text payload
Credits to PB95Player2024 for icon
Yeah, it's skidded