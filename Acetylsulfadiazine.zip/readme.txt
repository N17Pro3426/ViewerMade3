Acetylsulfadiazine.exe by Venrastuff
Do NOT run this malware on a real device!
If you do, I won't be responsible for ANY damages!
This was made for AntennaeTech's malware competition