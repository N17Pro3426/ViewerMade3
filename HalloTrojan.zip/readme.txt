HalloTrojan.exe
This is my new AI slop malware
Halloween is coming...
Works in Windows XP-11
Developed by NullOS404
No harmless version needed ;)
Bug: can't click trick and treat ;)
Credits to pankoza for the effects and wallpaper from SuperDeath3
Just short readme, because I don't have anything to talk about :/