obg.exe by VietNamLover
Credits to Clutter xmodz for the name.
This malware runs ONLY on 64-bit operating systems.
You need to install Visual C++ 2017 or 2015-2019 before running this malware.
This is a 10 payload malware.
Created on: August 26, 2026
This malware has a lot of destructive potential, so run it ONLY in a VM.
It contains flashing lights and loud sounds, so it's NOT for people with epilepsy or other similar medical conditions.
Differences compared to 2c34q6z735.exe by N17Pro3426 (he let me to remake his malware):
Changed some GDI payloads, all bytebeats, texts and MBR.