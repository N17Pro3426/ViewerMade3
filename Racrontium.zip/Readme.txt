Racrontium.exe
Created by: Marlon2210
Programming language: C++
Destructive: Yes
The non-safety will corrupt the MBR
I'm NOT responsible for ANY damages
Works in Windows Vista, 7, 8, 8.1, 10 and 11
If you want to run it on Windows XP, you'll need to install OneCore-API