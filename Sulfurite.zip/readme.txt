Sulfurite.exe
-------------------
Written in: Dev-C++ 5.11
Programming language: C++
Maded by transdows
Works in Windows XP-11
Original malware by Xip333, XxDaniel_PL, MalwareTheMaker and windows-7exeand8exe
Credits to pankoza for textout from skidded malware known as Triphenylarsine
Credits to wipet for 2 bytebeats
Credits to ArTicZera for tesseract from Purgatorium, but with shell32.dll icons
