Triphlrs.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 9 payloads.
Differences compared to Triphenylarsine.exe by pankoza:
Changed some bytebeats, all texts and the MBR.