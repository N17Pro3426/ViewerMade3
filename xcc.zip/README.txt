xcc.exe GDI malware
Do NOT run on any main PC's or use it for any illegal or harmful activity.
This must be run ONLY on a VM.
I'm NOT responsible for ANY damages caused by running this malware!
I also won't be making more for a while...
So I didn't get to finish some parts, but it works!
Made by CriticCookie