Beziriti2.0.exe by VietNamLover
This malware runs ONLY on 64-bit operating systems.
This is a 20 payload malware.
Created on: August 6, 2026
The destructive version has a lot of destructive potential, so run it ONLY in a VM.
Both versions contain flashing lights and loud sounds, so it's NOT for people with epilepsy or other similar medical conditions.
I'm too lazy to write the changelog.