0xCC.exe
--------------
Compatibility: Windows XP-11
Written in: Dev-C++
Programming language: C++
By running this, it won't cause any damages.
It just opening random programs from System32.
Do NOT download or run this on a main PC!