xiufamowcuyxvc.exe by UltraDasher965 & syexunii
Originally was called Hexaphenylarsine.exe, but it was scrapped.
This is a 16-payload long malware.
Don't try to run this malware on your real PC, as it'll do lots of damage to your device.
The creators aren't responsible for any damages made using this malware.
Credits to SapphireWindows for the TextOut system
Credits to LambdaTech for 1 payload
Hello, anyone who tests this malware!