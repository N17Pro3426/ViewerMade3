Cyanide.exe
Works on Windows XP-11
Run this ONLY on a VM.
If you click Yes, it'll destroy your PC and cause damages.
If you click No, nothing happens.
----------------------------
Thanks for reading
----------------------------
Credits to pankoza